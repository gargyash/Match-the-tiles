var values = [];
var tile_ids = [];
var size
var flipped_tiles = 0;
Array.prototype.memory_tile_shuffle = function(){
    var i = this.length, j, temp;
    while(--i > 0){
        j = Math.floor(Math.random() * (i+1));
        temp = this[j];
        this[j] = this[i];
        this[i] = temp;
    }
}
function newBoard(){
	var i=0;
	while(i==0){
	size = prompt("Please enter the grid size? (Any even number between 2 and 8)", 4);
	var x=100*size+"px";
	document.getElementById('memory_grid').style.height=x;
	document.getElementById('memory_grid').style.width=x;
        if(size!=null && size>=2 && size<=8 && size%2==0)
	i=1;
	else
	i=0;
        }
	var array = [];
        for(i=1; i<=(size*size)/2; i++){
        array.push(i);
	array.push(i);
        }
        flipped_tiles = 0;
	var output = '';
        array.memory_tile_shuffle();
	for(var i = 0; i < array.length; i++){
		output += '<div id="tile_'+i+'" onclick="FlipTile(this,\''+array[i]+'\')"></div>';
		
	}
	document.getElementById('memory_grid').innerHTML = output;
}
function check()
{
	if(flipped_tiles == size*size){
					document.getElementById('play').style.display="block";
				}	
}
	function FlipTile(tile,val){
	if(tile.innerHTML == "" && values.length < 2){
	tile.style.background = '#FFF';
		tile.innerHTML = val;
		if(values.length == 0){
			values.push(val);
			tile_ids.push(tile.id);
		} else if(values.length == 1){
			values.push(val);
			tile_ids.push(tile.id);
			if(values[0] == values[1]){
				flipped_tiles += 2;
				 var tile_1 = document.getElementById(tile_ids[0]);
				    var tile_2 = document.getElementById(tile_ids[1]);
				    tile_1.style.background = 'url(tick.jpeg)';
				    tile_2.style.background = 'url(tick.jpeg)';
				// Clear both arrays
				values = [];
            			tile_ids = [];
            			check();
				// Check to see if the whole board is cleared
				
		
				
			} else {
				function Back(){
				    // Flip the 2 tiles back over
				    var tile_1 = document.getElementById(tile_ids[0]);
				    var tile_2 = document.getElementById(tile_ids[1]);
				    tile_1.style.background = 'url(tile_bg.jpg) no-repeat';
            	    tile_1.innerHTML = "";
				    tile_2.style.background = 'url(tile_bg.jpg) no-repeat';
            	    tile_2.innerHTML = "";
				    // Clear both arrays
				    values = [];
            	    tile_ids = [];
				}
				setTimeout(Back, 700);
			}
		}
	}
}
